const produtos = [
    {id:1, nome: "Camisa", preco: 30.00},
    {id:2, nome: "Calça Jeans", preco: 90.00},
    {id:3, nome: "Tênis", preco: 150.00},
    {id:4, nome: "Meia", preco: 20.00}
];

const listaProdutosElemento = document.getElementById("listaProdutos");
const itensCarrinhoElemento = document.getElementById("itensCarrinho");
const qntTotalElemento = document.getElementById("qntTotal");

function puxarCarrinho(){
    const carrinho = localStorage.getItem('carrinhoEcommerce');
    return carrinho ? JSON.parse(carrinho) : [];
}

function salvarCarrinho(carrinho){
    localStorage.setItem('carrinhoEcommerce', JSON.stringify(carrinho));
}

function renderizarProdutos(){
    produtos.forEach(produtos => {
        const produtosElemento = document.createElement('div');
        produtosElemento.innerHTML = `
            <span>${produtos.nome} - R$ ${produtos.preco.toFixed(2)}</span>
            <button onclick="addCarrinho(${produtos.id})">Adicionar ao Carrinho</button>
        `;
        listaProdutosElemento.appendChild(produtosElemento);
    })
}

function addCarrinho(produtoId){
    const carrinho = puxarCarrinho();
    const produto = produtos.find(p => p.id === produtoId);

    if(produto){
        const itemExiste = carrinho.find(item => item.id === produtoId);
        if(itemExiste){
            itemExiste.quantidade++;
        }
        else {
            carrinho.push({ ...produto,quantidade: 1})
        }
        salvarCarrinho(carrinho);
        renderizarCarrinho();
    }
}

function renderizarCarrinho(){
    itensCarrinhoElemento.innerHTML = '';
    const carrinho = puxarCarrinho();
    let total = 0;

    carrinho.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.nome} x${item.quantidade} - R$ ${(item.preco * item.quantidade).toFixed(2)}`;
        itensCarrinhoElemento.appendChild(li);
        total += item.preco * item.quantidade;
    })

    qntTotalElemento.textContent = total.toFixed(2);
}

function limparCarrinho(){
    localStorage.removeItem('carrinhoEcommerce');
    renderizarCarrinho();
}

document.addEventListener('DOMContentLoaded', () => {
    renderizarProdutos();
    renderizarCarrinho();
})